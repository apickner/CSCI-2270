#include <string>

// takes each word in a specified text file and pushes it to the back of a vector
std::vector<std::string> fileToString(std::string fileName);
